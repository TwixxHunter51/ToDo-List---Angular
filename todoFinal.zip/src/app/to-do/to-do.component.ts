import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.css']
})

export class ToDoComponent implements OnInit{
  tasks: { name: string; originalName: string; expiry: number; editing: boolean; }[] = [];
  ctasks: { name: string; originalName: string; expiry: number;editing: boolean; }[] = [];  
  completedCount: number = 0;
  taskForm!: FormGroup;


  constructor(private formBuilder: FormBuilder , private toastr: ToastrService,private http: HttpClient) {}
  ngOnInit() {
    this.taskForm = this.formBuilder.group({
      task: ['', Validators.required],
      expiry: ['', Validators.pattern(/^\d+$/)] 
    });
  }
  
  addTask() {
    if (this.taskForm.valid) {
      const newTask = this.taskForm.get('task')!.value.trim();
      const expiryTime = +this.taskForm.get('expiry')!.value;
     
      if (newTask !== '') {
        // Send an HTTP POST request to the backend
        const taskToAdd = { Name: newTask };
        this.http.post<any>('http://localhost:57803//InsertTask', taskToAdd).subscribe(
          response => {
            if (response === 'Task Added Successfully!') {
              this.tasks.unshift({ name: newTask, expiry: expiryTime, editing: false, originalName: newTask });
              this.taskForm.reset();
              this.toastr.success('Task added successfully!');
              
              if (expiryTime > 0) {
                this.setExpiryTimeout(this.tasks[0]);
              }
            } else {
              this.toastr.error('Failed to add task.');
            }
          },
          error => {
            console.error('Error adding task:', error);
            this.toastr.error('An error occurred while adding the task.');
          }
        );
      }
    }
  }
  
  setExpiryTimeout(task: { name: string; originalName: string; expiry: number; editing: boolean; }) {
    setTimeout(() => {
      this.moveToCompleted(task, this.tasks.indexOf(task));
    }, task.expiry * 1000);
  }
  

  moveToCompleted(task: { name: string; originalName: string;expiry: number; editing: boolean; }, index: number) {
    this.ctasks.unshift(task);
    this.tasks.splice(index, 1);
    this.updateCompletedCount();
    this.toastr.success('Task completed successfully!', 'Congratulations!');
  }

  deleteTask(index: number) {
    if (index >= 0 && index < this.tasks.length) {
      this.tasks.splice(index, 1);
      this.toastr.success('Task deleted successfully!');
    }
  } 

  deleteCompletedTask(index: number) {
    if (index >= 0 && index < this.ctasks.length) {
      this.ctasks.splice(index, 1);
      this.updateCompletedCount();
      this.toastr.success('Task deleted successfully!');
    }
  }
  
  updateCompletedCount() {
    this.completedCount = this.ctasks.length;
  }

  startEditing(task: { name: string, editing: boolean }) {
    task.editing = true;
  }

  saveTask(task: { name: string, originalName:string,editing: boolean }) {
    if(task.name!='')
    {task.editing = false;
    task.originalName=task.name;
    this.toastr.success('Task edited successfully!');
    }
  }

  cancelEdit(task: { name: string,originalName:string, editing: boolean }) {
    task.editing = false;
    task.name = task.originalName;
  }

  dropActiveToCompleted(event: CdkDragDrop<{ name: string; originalName: string; expiry: number;editing: boolean; }[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(this.tasks, event.previousIndex, event.currentIndex); 
      this.toastr.success('Task priority changed!');
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      );
      this.updateCompletedCount();
      this.toastr.success('Task not completed yet!' , 'OOPS');
    }
  }

  dropCompletedToActive(event: CdkDragDrop<{ name: string; originalName: string;expiry: number; editing: boolean; }[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(this.ctasks, event.previousIndex, event.currentIndex); 
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      );
      this.updateCompletedCount();
      this.toastr.success('Task completed successfully!' , 'Congratulations!');
    }
  }
}